Jitter correction
=================

*Page in construction.*