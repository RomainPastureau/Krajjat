Stats functions
===============
