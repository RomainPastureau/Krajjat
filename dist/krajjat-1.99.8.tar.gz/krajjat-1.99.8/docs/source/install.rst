Installing Krajjat
==================

**Krajjat** is a Python package in development. You can install it by running the following command line:

.. code-block:: bash

	pip install -i https://test.pypi.org/simple/ krajjat

