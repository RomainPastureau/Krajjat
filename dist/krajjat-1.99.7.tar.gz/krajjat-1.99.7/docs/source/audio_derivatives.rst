Audio derivatives
=================

Description
-----------
Classes for time series derived from audio clips: Envelope, Intensity, Pitch and Formants.

AudioDerivative
---------------

Note
^^^^
This class is a parent class for :class:`Envelope`, :class:`Pitch`, :class:`Intensity` and :class:`Formant`. This class
should not be called directly: instead, the methods should be called through the child classes when an object is
created by one of the instances of the class :class:`Audio`.

Initialisation
^^^^^^^^^^^^^^
.. autoclass:: classes.audio_derivatives.AudioDerivative

Methods
^^^^^^^
.. automethod:: classes.audio_derivatives.AudioDerivative.set_name
.. automethod:: classes.audio_derivatives.AudioDerivative.get_samples
.. automethod:: classes.audio_derivatives.AudioDerivative.get_timestamps
.. automethod:: classes.audio_derivatives.AudioDerivative.get_frequency
.. automethod:: classes.audio_derivatives.AudioDerivative.get_name
.. automethod:: classes.audio_derivatives.AudioDerivative.get_number_of_samples
.. automethod:: classes.audio_derivatives.AudioDerivative.filter_frequencies
.. automethod:: classes.audio_derivatives.AudioDerivative.resample
.. automethod:: classes.audio_derivatives.AudioDerivative.__len__
.. automethod:: classes.audio_derivatives.AudioDerivative.__getitem__

All of the following classes inherit from AudioDerivative: all the methods described above can then be used for any
object from the classes below.

Envelope
--------
.. autoclass:: classes.audio_derivatives.Envelope

Pitch
-----
.. autoclass:: classes.audio_derivatives.Pitch

Intensity
---------
.. autoclass:: classes.audio_derivatives.Intensity

Formant
-------
.. autoclass:: classes.audio_derivatives.Formant
