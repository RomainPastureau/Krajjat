Installing Krajjat
==================

*To be completed*