Functions
=========

.. toctree::

   io_functions
   display_functions
   tool_functions
   plot_functions
   stats_functions