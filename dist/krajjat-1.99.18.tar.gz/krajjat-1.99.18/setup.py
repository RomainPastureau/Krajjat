from setuptools import setup, find_packages

setup(name='krajjat',
      version='1.99.18',
      packages=find_packages())