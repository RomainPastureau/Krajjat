from setuptools import setup, find_packages

setup(name='krajjat',
      version='1.99.20',
      packages=find_packages())