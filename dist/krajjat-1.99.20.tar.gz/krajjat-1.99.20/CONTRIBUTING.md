You are more than welcome to add your contribution to krajjat.
Before performing a pull request, be sure to check the documentation of the package, and to agree that your work will fall under the package license.
