from setuptools import setup, find_packages

setup(name='krajjat',
      version='1.99.19',
      packages=find_packages())