# Security Policy

## Supported Versions

| Version | Supported          |
|---------| ------------------ |
| 1.99.19 | :white_check_mark: |

## Reporting a Vulnerability

To report a vulnerability, please [open an issue on GitHub](https://github.com/RomainPastureau/Krajjat/security/advisories/new).